#!/usr/bin/python
texto = raw_input ("ingrese un texto:  ")
print texto
texto2 = raw_input ("ingrese un texto2:  ")
print texto2
if (texto[0] == texto2[0]):
	print "True"
else:
	print "False"



